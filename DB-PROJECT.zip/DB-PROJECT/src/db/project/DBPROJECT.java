/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ali Azeem Abbas
 */
public class DBPROJECT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        main m=new main();
        m.setVisible(true);
    }
    
       Connection conn = null;

    public Connection getConnection() throws ClassNotFoundException {

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/orclpdb", "hr", "hr");
            if (conn == null) {
                System.out.println("Unable to connect with database");
                return null;
            }
            System.out.println("Connected with database");
        } catch (SQLException ex) {
            Logger.getLogger(clients.class.getName()).log(Level.SEVERE, null, ex);
        }

        return conn;

    }
    
}
