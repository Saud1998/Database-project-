/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
public class clients_class {
        Connection conn = null;
        Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public Connection getConnection() throws ClassNotFoundException {

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/orclpdb", "hr", "hr");
            if (conn == null) {
                System.out.println("Unable to connect with database");
                return null;
            }
            System.out.println("Connected with database");
        } catch (SQLException ex) {
            Logger.getLogger(clients_class.class.getName()).log(Level.SEVERE, null, ex);
        }

        return conn;

    }

    public void insert_record() {
        PreparedStatement stmt = null;
        String query = "insert into hr.clients (client_id,city_id,fname,lname,address,email,phonenum) values(?,?,?,?,?,?,?)";
        try {
            Scanner x = new Scanner(System.in);

            stmt = conn.prepareStatement(query);
            stmt.setInt(1, Integer.parseInt(x.nextLine()));
            stmt.setInt(2, Integer.parseInt(x.nextLine()));
            stmt.setString(3, x.nextLine());
            stmt.setString(4, x.nextLine());
            stmt.setString(5, x.nextLine());
            stmt.setString(6, x.nextLine());
            stmt.setInt(7, Integer.parseInt(x.nextLine()));
            stmt.executeUpdate();
            stmt.close();
            System.out.println("record inserted");

        } catch (SQLException ex) {
            Logger.getLogger(clients_class.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    

    public void readRecords() {

        try {
            Statement stmt = conn.createStatement();
            String query = "select * from hr.clients ";

            ResultSet rs = stmt.executeQuery(query);
            //System.out.println("SUPNR:\tSUPNAME:\tSUPADDRESS:\t SUPCITY:\tSUPSTATUS:");
            while (rs.next()) {
                System.out.println(rs.getInt("client_id") + "\t" + rs.getInt("city_id") + "\t" + rs.getString("fname") + "\t" + rs.getString("lname") + "\t" + rs.getString("address")
                +rs.getString("email") +rs.getInt("phonenum"));

            }
            stmt.close();
            System.out.println("All the list");

        } catch (SQLException ex) {
            Logger.getLogger(clients_class.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updateRecord() throws SQLException {
        PreparedStatement stmt = null;
        Scanner x = new Scanner(System.in);
        String query = "update hr.clients set city_id=? where client_id=?";
        stmt = conn.prepareStatement(query);
        stmt.setString(1, x.nextLine());
        stmt.setInt(2, Integer.parseInt(x.nextLine()));
        stmt.executeQuery();
        stmt.close();
        System.out.println("Record updated");
    }

    public void deleteRecord() throws SQLException {
        PreparedStatement stmt = null;
        Scanner x = new Scanner(System.in);
        String query = "delete from hr.clients  where client_id=?";
        stmt = conn.prepareStatement(query);
        stmt.setInt(1, Integer.parseInt(x.nextLine()));
        stmt.executeQuery();
        stmt.close();
        System.out.println("Record deleted");

    }
    
}
